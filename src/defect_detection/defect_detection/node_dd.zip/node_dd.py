#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
import torch
import torch.nn as nn
from torchvision import transforms
import segmentation_models_pytorch as smp
import cv2
import numpy as np
from PIL import Image as PILImage
import os
import shutil
import sys
import traceback
# ==========================================
# MODÈLE 3 (CNN CLASSIQUE) 
# ==========================================
class ClassicCNN(nn.Module):
    def __init__(self):
        super(ClassicCNN, self).__init__()
        self.features = nn.Sequential(
            nn.Conv2d(1, 16, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.MaxPool2d(2, 2),
            nn.Conv2d(16, 32, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.MaxPool2d(2, 2),
            nn.Conv2d(32, 64, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.MaxPool2d(2, 2)
        )
        self.classifier = nn.Sequential(
            nn.Flatten(),
            nn.Linear(64 * 8 * 8, 128),
            nn.ReLU(),
            nn.Dropout(0.5),
            nn.Linear(128, 1)
        )
    def forward(self, x):
        x = self.features(x)
        x = self.classifier(x)
        return x
# ==========================================
class DefectDetectionOfflineNode(Node):
    def __init__(self):
        super().__init__('node_dd_offline')
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        
        # --- 1. SETTINGS & PATHS ---
        self.target_count = 4  # Attendre 4 images comme demandé
        self.seuil_ia = 0.4    # Seuil de confiance IA
        self.seuil_pourcentage_masque = 0.1 
        
        # Utilisation des chemins de ton collègue
        self.input_folder = os.path.expanduser('~/new_ws_compressed/new_ws/inspection_results')
        self.result_folder = os.path.expanduser('~/new_ws_compressed/new_ws/src/defect_detection/results')
        model_folder = os.path.expanduser('~/new_ws_compressed/new_ws/src/defect_detection/modeles/')
        
        # Reset output folder
        if os.path.exists(self.result_folder):
            shutil.rmtree(self.result_folder)
        os.makedirs(self.result_folder)
            
        # --- 2. MODEL INITIALIZATION ---
        self.model_unet = smp.Unet(encoder_name="resnet34", classes=1, activation=None)
        self.model_classif = ClassicCNN()
        
        unet_path = os.path.join(model_folder, 'model_BEST_val.pth')
        cnn_path = os.path.join(model_folder, 'cnn_classifier_BEST.pth')
        try:
            # Chargement sécurisé (strict=False pour le U-Net)
            self.model_unet.load_state_dict(torch.load(unet_path, map_location=self.device), strict=False)
            self.model_classif.load_state_dict(torch.load(cnn_path, map_location=self.device))
            
            self.model_unet.to(self.device).eval()
            self.model_classif.to(self.device).eval()
            self.get_logger().info("✅ Models loaded successfully (512x512 config).")
        except Exception as e:
            self.get_logger().error(f"❌ Load error: {e}")
            sys.exit(1)
        # --- 3. PREPROCESSING (Version optimisée) ---
        self.preprocess_unet = transforms.Compose([
            transforms.Resize((512, 512)),
            transforms.ToTensor()
        ])
        self.preprocess_classif = transforms.Compose([
            transforms.Resize((64, 64)),
            transforms.Grayscale(num_output_channels=1),
            transforms.ToTensor(),
            transforms.Normalize([0.5], [0.5])
        ])
        # --- 4. EXECUTE BATCH ---
        self.run_batch_inference()
        
        self.get_logger().info("\uD83D\uDC4B Batch processing complete. Shutting down.")
        sys.exit(0)
    def run_batch_inference(self):
        if not os.path.exists(self.input_folder):
            self.get_logger().error(f"Folder not found: {self.input_folder}")
            return
        # Filtrer et limiter à 4 images
        all_photos = sorted([f for f in os.listdir(self.input_folder) if f.endswith('.png')])
        photos = all_photos[:self.target_count]
        
        if not photos:
            self.get_logger().warn(f"No .png images found in {self.input_folder}.")
            return
        self.get_logger().info(f"\uD83D\uDD0E Found {len(all_photos)} photos. Processing the first {len(photos)}...")
        for photo_name in photos:
            self.get_logger().info(f"\uD83E\uDDEA Processing {photo_name}...")
            path = os.path.join(self.input_folder, photo_name)
            cv_img = cv2.imread(path)
            if cv_img is None: continue
            img_pil = PILImage.fromarray(cv2.cvtColor(cv_img, cv2.COLOR_BGR2RGB))
            final_img = cv_img.copy()
            
            # Step 1: U-Net
            input_tensor = self.preprocess_unet(img_pil).unsqueeze(0).to(self.device)
            with torch.no_grad():
                out_seg = self.model_unet(input_tensor)
                prob_mask = torch.sigmoid(out_seg).squeeze().cpu().numpy()
            
            h, w = cv_img.shape[:2]
            prob_mask_resized = cv2.resize(prob_mask, (w, h))
            
            # Seuil optimisé à 0.4
            binary_mask = (prob_mask_resized > self.seuil_ia).astype(np.uint8)
            
            # Fermeture morphologique pour boucher les trous (intérieur orange)
            kernel_close = np.ones((25, 25), np.uint8)
            binary_mask = cv2.morphologyEx(binary_mask, cv2.MORPH_CLOSE, kernel_close)
            
            pixels_blancs = np.sum(binary_mask)
            pourcentage_blanc = (pixels_blancs / (h * w)) * 100.0
            
            if pourcentage_blanc >= self.seuil_pourcentage_masque:
                num_labels, labels, stats, centroids = cv2.connectedComponentsWithStats(binary_mask, 8)
                color_layer = np.zeros_like(cv_img)
                
                # Step 2: CNN (Classification)
                for i in range(1, num_labels):
                    mask_i = (labels == i).astype(np.uint8) * 255
                    
                    img_iso_cv = cv2.bitwise_and(cv_img, cv_img, mask=mask_i)
                    img_iso_pil = PILImage.fromarray(cv2.cvtColor(img_iso_cv, cv2.COLOR_BGR2RGB))
                    
                    input_class = self.preprocess_classif(img_iso_pil).unsqueeze(0).to(self.device)
                    
                    with torch.no_grad():
                        out_class = self.model_classif(input_class)
                        prob = torch.sigmoid(out_class).item()
                    
                    cx, cy = int(centroids[i][0]), int(centroids[i][1])
                    
                    if prob > 0.5:
                        defect_name, color = "SCRATCH", (0, 0, 255) # Rouge
                    else:
                        defect_name, color = "HOLE", (255, 0, 0)   # Bleu
                    
                    # Dilatation pour l'affichage visuel
                    mask_thick = cv2.dilate(mask_i, np.ones((15, 15), np.uint8), iterations=1)
                    color_layer[mask_thick == 255] = color
                    cv2.putText(final_img, defect_name, (cx - 30, cy - 20), 
                                cv2.FONT_HERSHEY_SIMPLEX, 0.7, color, 2, cv2.LINE_AA)
                final_img = cv2.addWeighted(final_img, 0.7, color_layer, 0.3, 0)
            
            # Note : Le texte "0 DEFECT" a été supprimé comme demandé
            # Step 3: Save and Show
            res_path = os.path.join(self.result_folder, f"result_{photo_name}")
            cv2.imwrite(res_path, final_img)
            
            cv2.imshow("IA RESULTS", final_img)
            cv2.waitKey(1500) 
def main(args=None):
    rclpy.init(args=args)
    try:
        node = DefectDetectionOfflineNode()
        rclpy.spin(node)
    except SystemExit:
        pass 
    except KeyboardInterrupt:
        pass
    finally:
        cv2.destroyAllWindows()
        rclpy.shutdown()
if __name__ == '__main__':
    main()
